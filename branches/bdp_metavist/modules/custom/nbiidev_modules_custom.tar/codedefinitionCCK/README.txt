This is a Drupal Module - Quantitative Attribute Accuracy Assesment Field
It implements a data set's Quantitative Attribute Accuracy Assesment field for CCK

Copyright 2011 Inigo San Gil, LTER/NBII

Licensed under the GNU Public License (see LICENSE.txt)

